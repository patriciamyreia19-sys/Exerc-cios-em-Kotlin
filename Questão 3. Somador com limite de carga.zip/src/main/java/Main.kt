fun main() {
    
/* 3.Crie um programa que itere de 1 a 100 somando os valores em uma variável total. Se o
número atual for múltiplo de 10, utilize continue para não adicioná-lo à soma. Se em
algum momento a variável total ultrapassar o valor de 500, aborte o laço com break
e exiba o valor final. */
    
var total = 0

    for (numero in 1..100) {
        // Se o número for múltiplo de 10, usamos continue para pular a adição
        if (numero % 10 == 0) {
            continue
        }

        // Soma o número atual à variável total
        total += numero
        println("Somando $numero | Total parcial: $total")

        // Se o total ultrapassar 500, encerramos o laço imediatamente
        if (total > 500) {
            println("\nO total ultrapassou 500! Abortando o laço.")
            break
        }
    }

    println("\nValor final da variável total: $total")
}
