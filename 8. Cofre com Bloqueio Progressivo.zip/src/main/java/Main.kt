fun main() {
    
/*  8. Simule um sistema de tentativas de senha. O usuário tem 5 chances máximas (um for
de 1 a 5. Se a senha simulada for correta, conceda acesso e use break. Se errar,
avise. Se errar a terceira vez, não permita as outras duas tentativas: imprima "Cofre
travado administrativamente" e acione um break. */

    val senhaCorreta = "1234"
    val maxTentativas = 5

    for (tentativaAtual in 1..maxTentativas) {
        print("Tentativa $tentativaAtual de $maxTentativas - Digite a senha: ")
        val senhaDigitada = readln()

        if (senhaDigitada == senhaCorreta) {
            println("Acesso concedido! Cofre aberto.")
            break // Acertou, encerra o laço com sucesso
        } else {
            println("Senha incorreta!")

            // Se errou pela terceira vez, trava administrativamente
            if (tentativaAtual == 3) {
                println("\nCofre travado administrativamente por excesso de tentativas incorretas.")
                break // Encerra o laço antes de completar as 5 tentativas
            }
        }
    }
}
    
    
    

