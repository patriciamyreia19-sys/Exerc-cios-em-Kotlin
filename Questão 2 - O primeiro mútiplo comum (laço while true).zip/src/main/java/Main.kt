fun main(){
 
/* 2. Construa um laço while (true) começando com uma variável numero = 1.
Verifique se o número é divisível simultaneamente por 7 e por 13. Quando encontraresse número, imprima-o na tela e encerre o laço imediatamente com break. Caso
contrário, incremente a variável.*/   

    var numero = 1

    while (true) {
        // Verifica se o número é divisível por 7 E por 13 ao mesmo tempo
        // O operador '%' calcula o resto da divisão. Se for 0, é divisível.
        if (numero % 7 == 0 && numero % 13 == 0) {
            println("Número encontrado: $numero")
            break // Encerra o laço imediatamente
        }
        
        // Caso contrário, incrementa a variável para testar o próximo número
        numero++
    }
}
   


