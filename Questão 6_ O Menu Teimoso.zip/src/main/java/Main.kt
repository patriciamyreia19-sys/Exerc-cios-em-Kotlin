fun main() {
/* Construa um menu dentro de um laço infinito simulando entradas de opções 1, 2, 3 ou
0.
Se a opção for 1 ou 2, imprima "Processando...".
Se a opção for 3, imprima "Módulo em manutenção" e use continue para
voltar ao início instantaneamente.
Se for 0, encerre o programa com break. */

  // Laço infinito para o menu continuar rodando até que o usuário decida sair
    while (true) {
        println("\nEscolha uma opção: (1, 2, 3 ou 0 para sair)")
        val opcao = readln().toIntOrNull()

        // Se escolher 1 ou 2
        if (opcao == 1 || opcao == 2) {
            println("Processando...")
        } 
        // Se escolher 3 (Módulo em manutenção)
        else if (opcao == 3) {
            println("Módulo em manutenção. Voltando ao início...")
            continue // Pula o resto do código e volta para o topo do while imediatamente
        } 
        // Se escolher 0 (Sair)
        else if (opcao == 0) {
            println("Encerrando o programa.")
            break // Quebra o laço infinito e fecha o programa
        } 
        // Se digitar qualquer outra coisa inválida
        else {
            println("Opção inválida!")
        }
    }
}
