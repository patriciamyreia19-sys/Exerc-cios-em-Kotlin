fun main(){
/*Dado um número alvo (ex: 29, crie um laço que vá de 2 até alvo - 1. Se o alvo for
divisível por qualquer um desses números no caminho (resto zero), altere uma variável
ehPrimo para false e acione um break para não desperdiçar processamento
testando os próximos. */

    val alvo = 29
    var ehPrimo = true

    // Laço que vai de 2 até um número antes do alvo (utilizando until)
    for (i in 2 until alvo) {
        // Se o alvo for divisível por i significa que tem divisor além de 1 e dele mesmo
        if (alvo % i == 0) {
            ehPrimo = false
            break // Para de gastar processamento testando os próximos números
        }
    }

    if (ehPrimo) {
        println("$alvo é um número primo!")
    } else {
        println("$alvo não é um número primo.")
    }
}

    


