fun main() {
   
/* 1. Dada a string palavra = "Universidade", utilize um laço for para percorrer cada
caractere. Se o caractere for uma vogal (a, e, i, o, u), utilize continue para ignorá-lo.
Imprima apenas as consoantes. */

    val palavra = "Universidade"
    
    println("Imprimindo somente as consoantes de '$palavra':")
    
    for (char in palavra) {
        // Convertemos para minúscula para facilitar a verificação da vogal
        val letraMinuscula = char.lowercaseChar()
        
        // Se for vogal, usamos 'continue' para ignorar a impressão desta letra
        if (letraMinuscula == 'a' || letraMinuscula == 'e' || letraMinuscula == 'i' || 
            letraMinuscula == 'o' || letraMinuscula == 'u') {
            continue
        }
        
        // Se passou do if, significa que é uma consoante
        println(char)
    }
}

    
    
    
    
    


