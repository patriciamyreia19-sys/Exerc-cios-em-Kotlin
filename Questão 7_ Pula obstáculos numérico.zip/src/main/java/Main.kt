fun main(){

/* 7. Itere os números de 1 a 50. Seu programa deve imprimir todos os números, exceto
aqueles que terminam com o dígito 7 7, 17, 27...). Use uma condicional verificando se
numero % 10 == 7 para acionar um continue. */

    println("Imprimindo números de 1 a 50 (pulando os terminados em 7):")

    for (numero in 1..50) {
        // Verifica se o resto da divisão por 10 é igual a 7 (ex: 17 % 10 = 7)
        if (numero % 10 == 7) {
            continue // Pula a impressão deste número e vai para o próximo da lista
        }

        println(numero)
    }
}
    


