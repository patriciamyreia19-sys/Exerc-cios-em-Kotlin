fun main() {
    
/* 4. Declare um saldo inicial de R$ 1000,00. Crie um laço infinito onde, a cada iteração, é
simulada uma tentativa de saque de R$ 150,00. Se o saldo for suficiente, deduza o
valor. Quando o saldo ficar menor que o valor do saque, exiba "Saldo Insuficiente" e
encerre a operação com break. */    
    var saldo = 1000.0
    val valorSaque = 150.0

    while (true) {
        // Verifica se há saldo suficiente para o saque
        if (saldo >= valorSaque) {
            saldo -= valorSaque // Deduz o valor do saque do saldo atual
            println("Saque de R$ $valorSaque realizado com sucesso! Saldo atual: R$ $saldo")
        } else {
            // Se o saldo for menor que o valor do saque
            println("Saldo Insuficiente (R$ $saldo). Encerrando operações.")
            break // Encerra o laço infinito
        }
    }
}


